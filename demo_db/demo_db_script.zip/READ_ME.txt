Добавьте новую PostgreSQL базу данных
Запустите demo_db_script_1.sql (создадутся 8 таблиц и заполнятся 6 из них)
Запустите demo_db_script_2.sql (заполнится 7-ая таблица (visitor))
Запустите demo_db_script_3.sql (заполнится 8-ая таблица (visitor_schedule))



