-- create all tables
CREATE TABLE IF NOT EXISTS public.museum (
  museum_id INTEGER NOT NULL,
  museum_name VARCHAR(70) NOT NULL,
  address VARCHAR(70) NOT NULL,
  foundation_year INTEGER NOT NULL,
  latitude FLOAT(6) NOT NULL,
  longitude FLOAT(6) NOT NULL
);
CREATE TABLE IF NOT EXISTS public.excursion (
  excursion_id INTEGER NOT NULL,
  excursion_name VARCHAR(100) NOT NULL,
  museum_id INTEGER NOT NULL,
  price INTEGER NOT NULL,
  guide_id INTEGER
);
CREATE TABLE IF NOT EXISTS public.visitor (
  visitor_id INTEGER NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  gender CHAR(1) NOT NULL
);
CREATE TABLE IF NOT EXISTS public.schedule (
  schedule_id INTEGER NOT NULL,
  excursion_id INTEGER NOT NULL,
  starts_on TIMESTAMP NOT NULL
);
CREATE TABLE IF NOT EXISTS public.visitor_schedule (
  visitor_id INTEGER NOT NULL,
  schedule_id INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS public.hall (
  hall_id INTEGER NOT NULL,
  hall_name VARCHAR(100) NOT NULL,
  floor INTEGER NOT NULL,
  museum_id INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS public.exhibit (
  exhibit_id INTEGER NOT NULL,
  exhibit_name VARCHAR(150) NOT NULL,
  author VARCHAR(150),
  hall_id INTEGER NOT NULL,
  year_of_creation INTEGER,
  country_of_creation VARCHAR(50)
);
CREATE TABLE IF NOT EXISTS public.guide (
  guide_id INTEGER NOT NULL,
  first_name VARCHAR(20) NOT NULL,
  phone CHAR(12) NOT NULL
);
ALTER TABLE public.museum ADD PRIMARY KEY (museum_id);
ALTER TABLE public.excursion ADD PRIMARY KEY (excursion_id);
ALTER TABLE public.visitor ADD PRIMARY KEY (visitor_id);
ALTER TABLE public.schedule ADD PRIMARY KEY (schedule_id);
ALTER TABLE public.hall ADD PRIMARY KEY (hall_id);
ALTER TABLE public.exhibit ADD PRIMARY KEY (exhibit_id);
ALTER TABLE public.guide ADD PRIMARY KEY (guide_id);

ALTER TABLE public.visitor_schedule ADD CONSTRAINT fk_visitor_id FOREIGN KEY (visitor_id) REFERENCES public.visitor(visitor_id);
ALTER TABLE public.visitor_schedule ADD CONSTRAINT fk_schedule_id FOREIGN KEY (schedule_id) REFERENCES public.schedule(schedule_id);
ALTER TABLE public.schedule ADD CONSTRAINT fk_excursion_id FOREIGN KEY (excursion_id) REFERENCES public.excursion(excursion_id);
ALTER TABLE public.excursion ADD CONSTRAINT fk_museum_id_excursion FOREIGN KEY (museum_id) REFERENCES public.museum(museum_id);
ALTER TABLE public.excursion ADD CONSTRAINT fk_guide_id FOREIGN KEY (guide_id) REFERENCES public.guide(guide_id);
ALTER TABLE public.hall ADD CONSTRAINT fk_museum_id_hall FOREIGN KEY (museum_id) REFERENCES public.museum(museum_id);
ALTER TABLE public.exhibit ADD CONSTRAINT fk_hall_id FOREIGN KEY (hall_id) REFERENCES public.hall(hall_id);

--insert into museum
INSERT INTO public.museum (museum_id, museum_name, address, foundation_year, latitude, longitude) VALUES (10, 'Государственный Эрмитаж', 'Дворцовая площадь, 2', 1764, 59.93974, 30.31408);
INSERT INTO public.museum (museum_id, museum_name, address, foundation_year, latitude, longitude) VALUES (20, 'Музей Фаберже', 'Набережная реки Фонтанки, 21', 2013, 59.934444, 30.343056);
INSERT INTO public.museum (museum_id, museum_name, address, foundation_year, latitude, longitude) VALUES (30, 'Государственный Русский музей', 'Инженерная улица, 4', 1978, 59.93859, 30.33222);
INSERT INTO public.museum (museum_id, museum_name, address, foundation_year, latitude, longitude) VALUES (40, 'Государственный музей «Царскосельская коллекция»', 'Пушкин, Магазейная улица, 40', 1991, 59.72305, 30.408283);

--insert into guide
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (1, 'Михаил', '+71834567390');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (5, 'Мария', '+71834562824');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (7, 'Андрей', '+71834680865');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (11, 'Наталья', '+70234527821');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (2, 'Ольга', '+70644113854');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (3, 'Иван', '+70834567892');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (4, 'Евгения', '+72834465827');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (6, 'Михаил', '+70635267816');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (8, 'Александра', '+72934004873');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (9, 'Зоя', '+72434117011');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (10, 'Дарья', '+70834513888');
INSERT INTO public.guide (guide_id, first_name, phone) VALUES (12, 'Алла', '+71634432813');


--insert into excursion
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (1, 'Главный музейный комплекc', 10, 500, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (2, 'Золотая кладовая', 10, 1000, 1);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (3, 'Бриллиантовая кладовая', 10, 1000, 2);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (4, 'Главный музейный комплекс (обзорная)', 10, 1000, 3);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (5, 'Главный Штаб (обзорная)', 10, 1000, 4);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (6, 'Приключения богини Сохмет', 10, 600, 5);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (7, 'В мире прекрасного', 10, 600, 5);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (8, 'Дворец Меньшикова', 10, 600, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (9, 'Музей Императорского фарфорового завода', 10, 300, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (10, 'Зимний дворец Петра I', 10, 600, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (11, 'Основная экспозиция Музея Фаберже', 20, 500, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (12, 'Экскурсионный сеанс по Музею Фаберже', 20, 1000, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (13, 'Диковинные вещицы Фаберже', 20, 750, 6);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (14, 'Драгоценный зоопарк', 20, 500, 7);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (15, 'Сказка в музее Фаберже', 20, 500, 7);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (16, 'Средства связи времен Фаберже', 20, 750, 8);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (17, 'Михайловский дворец', 30, 550, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (18, 'Корпус Бенуа', 30, 450, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (19, 'Михаил Врубель. К 165-летию со дня рождения', 30, 1000, 9);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (20, 'Мраморный и Строгановский дворцы', 30, 500, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (21, 'Константин Романов - поэт (К.Р): жизнь и судьба', 30, 800, 9);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (22, 'Домик Петра I', 30, 400, 10);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (23, 'Летний дворец Петра I', 30, 800, 11);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (24, 'Вход на основную экспозицию', 40, 100, NULL);
INSERT INTO public.excursion (excursion_id, excursion_name, museum_id, price, guide_id) VALUES (25, 'Экскурсионный сеанс по музею', 40, 250, 12);


-- insert into hall
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (1, 'Зал культуры и искусства Урарту', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (2, 'Зал культуры и искусства древнего Ближнего Востока', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (3, 'Зал Древнего Египта', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (4, 'Зал Диониса. Римская декоративная скульптура', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (5, 'Зал Афины. Искусство Древней Греции эпохи классики', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (6, 'Зал Геракла. Искусство Древней Греции IV в. до н. э', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (7, 'Зал культуры и искусства эпохи эллинизма', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (8, 'Зал Большой вазы. Искусство Рима эпохи императоров Траяна и Адриана, конец I - II в.', 1, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (9, 'Древнерусская иконопись XIV — начала XVIII века', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (10, 'Древнерусская культура', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (11, 'Портретная галерея дома Романовых', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (12, 'Ротонда', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (13, 'Концертный зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (14, 'Фельдмаршальский зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (15, 'Гербовый зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (16, 'Военная галерея 1812 года', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (17, 'Георгиевский (Большой тронный) зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (18, 'Павильонный зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (19, 'Зал искусства Италии эпохи Возрождения XV в.', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (20, 'Зал Леонардо да Винчи', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (21, 'Зал искусства Венеции XVI в.', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (22, 'Зал Тициана', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (23, 'Зал Рафаэля', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (24, 'Итальянский кабинет', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (25, 'Большой итальянский просвет', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (26, 'Зал Снейдерса', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (27, 'Зал Рубенса', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (28, 'Зал Рембрандта', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (29, 'Искусство Германии XV—XVIII вв', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (30, 'Зал искусства Франции XVII в. Зал Пуссена', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (31, 'Белый зал', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (32, 'Зал искусства Великобритании', 2, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (33, 'Зал культуры и искусства Китая', 3, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (34, 'Зал буддийского искусства Монголии и Тибета', 3, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (35, 'Зал искусства и культуры Ближнего Востока исламского периода VIII—XII вв', 3, 10);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (36, 'Рыцарский зал', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (37, 'Красная гостиная', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (38, 'Синяя гостиная', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (39, 'Золотая гостиная', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (40, 'Аванзал', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (41, 'Белая и Голубая гостинные', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (42, 'Выставочный зал', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (43, 'Готический зал', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (44, 'Верхняя буфетная', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (45, 'Бежевый зал', 2, 20);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (46, 'Древнейшие иконы', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (47, 'Андрей Рублев', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (48, 'И. Я. Вишняков, А. П. Антропов, И. П. Аргунов', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (49, 'Академический зал. К. П.Брюллов, И. К. Айвазовский', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (50, 'С. Ф. Щедрин', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (51, 'Ф. А. Васильев', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (52, 'В. Г. Перов', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (53, 'И. И. Шишкин', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (54, 'А. К. Саврасов', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (55, 'И. Е. Репин', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (56, 'А. И. Куинджи', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (57, 'В. И. Суриков', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (58, 'В. М. Васнецов', 1, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (59, 'В. А. Серов, П.Трубецкой', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (60, 'М. А. Врубель', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (61, 'Кубофутуризм (Л. С. Попова, Н. А. Удальцова, Н. С. Гончарова). В. В. Кандинский', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (62, 'К. С. Малевич, М. В. Матюшин, В. Е. Татлин', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (63, 'Музей Людвига в Русском музее. Мировое искусство XX века', 2, 30);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (64, 'Арефьевский круг', 2, 40);
INSERT INTO public.hall (hall_id, hall_name, floor, museum_id) VALUES (65, 'Зал 1920 — 1940', 2, 40);


--insert into exhibit
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (1, 'Фигура для украшения трона', NULL, 1, NULL, 'Урарту');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (2, 'Карас', NULL, 1, NULL, 'Урарту');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (3, 'Шлем царя Сардури II', NULL, 1, NULL, 'Урарту');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (4, 'Табличка с пиктографическими (протоклинописными) знаками', NULL, 2, NULL, NULL);
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (5, 'Гиря для взвешивания серебра', NULL, 2, NULL, 'Древний Иран');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (6, 'Статуя Аменемхета III', NULL, 3, NULL, 'Древний Египет');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (7, 'Статуя Клеопатры VII', NULL, 3, NULL, 'Древний Египет');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (8, 'Статуя богини Мут-Сохмет', NULL, 3, NULL, 'Древний Египет');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (9, 'Афродита (Венера Таврическая)', NULL, 4, NULL, 'Древняя Греция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (10, 'Дионис. Бог вина и виноделия, покровитель растительных сил природы', NULL, 4, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (11, 'Статуя жрицы', NULL, 4, NULL, NULL);
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (12, 'Статуя Афины', NULL, 5, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (13, 'Надгробие Филостраты', NULL, 5, NULL, 'Аттика');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (14, 'Фрагмент рельефа "Геракл в саду Гесперид', NULL, 5, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (15, 'Статуя отдыхающего Геракла', NULL, 6, NULL, NULL);
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (16, 'Эрот, натягивающий лук', NULL, 6, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (17, 'Две девушки (эфедризм)', NULL, 7, NULL, 'Коринф');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (18, 'Исида', NULL, 7, NULL, 'Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (19, 'Портрет римлянки', NULL, 8, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (20, 'Портрет Антиноя-Диониса', NULL, 8, NULL, 'Древний Рим');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (21, 'Икона: Иоанн Богослов в молчании', 'Нектарий Кулюксин', 9, 1679, 'Русский Север');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (22, 'Икона: Богоматерь Казанская', 'Ушаков, Симон Фёдорович.', 9, 1676, '');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (23, 'Икона: Мученики Флор и Лавр', NULL, 9, NULL, 'Ростовская провинция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (24, 'Височное кольцо трехбусинное', NULL, 10, NULL, 'Древняя Русь');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (25, 'Тмутараканский камень', NULL, 10, NULL, 'Древняя Русь');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (26, 'Портрет императора Петра I (1672-1725) (копия)', 'Белли', 11, NULL, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (27, 'Портрет императрицы Александры Федоровны', 'Кристина Робертсон', 11, 1841, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (28, 'Полтавская баталия', 'Каравак, Луи', 12, 1718, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (29, 'Портрет императора Петра I', 'Растрелли, Бартоломео Карло', 12, 1730, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (30, 'Рака Александра Невского', 'Гроот, Георг Кристоф', 13, 1751, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (31, 'Портрет графа И.И. Дибича', 'Басин, Пётр Васильевич', 14, 1833, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (32, 'Портрет генерал-фельдмаршала князя Михаила Илларионовича Голенищева-Кутузова (1745-1813)', 'Басин, Пётр Васильевич', 14, 1834, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (33, 'Ваза "Россия"', 'Моро, Дени-Жозеф;  Давиньон, Жак Фердинанд; Шрейбер, Андрей; Мадерни, Викентий Ф.; Райт, Томас; Шилов, Иван Анфимович', 14, 1828, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (34, 'Часть Белого (Гербового) зала в Зимнем дворце', 'Ладюрнер, Адольф Игнатьевич', 15, 1838, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (35, 'Чаша', NULL, 15, 1842, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (36, 'Портрет Михаила Илларионовича Кутузова (1747-1813)', 'Доу, Джордж', 16, 1829, 'Англия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (37, 'Портрет Михаила Богдановича Барклая-де-Толли (1761-1818)', 'Доу, Джордж', 16, 1829, 'Англия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (38, 'Портрет Александра I (1777-1825) верхом на коне', 'Крюгер, Франц', 16, 1837, 'Германия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (39, 'Портрет Франца I (1768-1835)', 'Крафт, Иоганн Петер', 16, 1832, 'Австрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (40, 'Тронное кресло и скамейка для ног ', NULL, 17, 1731, 'Великобритания, Лондон');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (41, 'Обелиск', NULL, 17, 1801, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (42, 'Часы "Павлин"', 'Кокс, Джеймс', 18, 1772, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (43, 'Стол с мозаичной столешницей "Аполлон и Музы"', 'Мокиутти, Эдоардо', 18, 1873, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (44, 'Мадонна с Младенцем на троне', 'Строцци, Дзаноби', 19, 1419, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (45, 'Видение блаженного Августина', 'Липпи, Филиппо фра', 19, 1460, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (46, 'Мадонна с Младенцем и четырьмя ангелами', 'Анджелико, фра Беато', 19, 1420, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (47, 'Мадонна с Младенцем (Мадонна Литта)', 'Леонардо да Винчи', 20, 1495, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (48, 'Мадонна с Младенцем (Мадонна Бенуа)', 'Леонардо да Винчи', 20, 1480, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (49, 'Кающаяся Мария Магдалина ', 'Джампьетрино (Джан Пьетро Риццоли)', 20, NULL, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (50, 'Юдифь', 'Джорджоне (Джорджо Барбарелли да Кастельфранко)', 21, 1504, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (51, 'Благовещение', 'Чима да Конельяно, Джованни Баттиста', 21, 1495, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (52, 'Мадонна с Младенцем', 'Виварини, Бартоломео', 21, 1490, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (53, 'Кающаяся Мария Магдалина', 'Тициан (Тициано Вечеллио)', 22, 1560, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (54, 'Даная', 'Тициан (Тициано Вечеллио)', 22, 1554, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (55, 'Св. Себастьян', 'Тициан (Тициано Вечеллио)', 22, 1576, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (56, 'Брак в Кане Галилейской', 'Гарофало (Бенвенуто Тизи)', 23, 1531, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (57, 'Чаша "Несение креста"', 'Никола да Урбино', 23, NULL, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (58, 'Святое семейство (Мадонна с безбородым Иосифом)', 'Рафаэль (Рафаэлло Санти)', 23, 1507, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (59, 'Мадонна с Младенцем (Мадонна Конестабиле)', 'Рафаэль (Рафаэлло Санти)', 23, 1504, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (60, 'Святой Иосиф с Младенцем Христом на руках', 'Рени, Гвидо', 24, 1635, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (61, 'Взятие Марии Магдалины на небо', 'Доменикино (Доменико Цампьери)', 24, 1621, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (62, 'Отдых святого семейства на пути в Египет ', 'Карраччи, Аннибале', 24, 1604, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (63, 'Исцеление Товита', 'Строцци, Бернардо', 25, 1632, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (64, 'Смерть св. Иосифа', 'Креспи, Джузеппе Мариа (Ло Спаньоло)', 25, 1712, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (65, 'Блудный сын', 'Роза, Сальватор', 25, 1650, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (66, 'Кузница Вулкана', 'Джордано, Лука', 25, 1660, 'Италия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (67, 'Повар у стола с дичью', 'Снейдерс, Франс', 26, 1637, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (68, 'Сцена в кабачке', 'Браувер, Адриан', 26, 1770, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (69, 'Персей освобождает Андромеду', 'Рубенс, Питер Пауль (Пьетро Пауло) ', 27, 1622, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (70, 'Венера и Адонис', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1611, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (71, 'Союз Земли и Воды (Шельда и Антверпен)', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1618, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (72, 'Вакх', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1639, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (73, 'Отцелюбие римлянки (Кимон и Перо)', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1612, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (74, 'Уход Агари из дома Авраама', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1616, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (75, 'Пир у Симона Фарисея', 'Рубенс, Питер Пауль (Пьетро Пауло)', 27, 1619, 'Фландрия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (76, 'Старушка с очками в руках', 'Рембрандт Харменс ван Рейн', 28, 1634, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (77, 'Возвращение блудного сына', 'Рембрандт Харменс ван Рейн', 28, 1668, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (78, 'Давид и Ионафан', 'Рембрандт Харменс ван Рейн', 28, 1642, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (79, 'Флора', 'Рембрандт Харменс ван Рейн', 28, 1634, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (80, 'Портрет Бартье Мартенс Доомер', 'Рембрандт Харменс ван Рейн', 28, 1640, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (81, 'Жертвоприношение Авраама', 'Рембрандт Харменс ван Рейн', 28, 1635, 'Голландия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (82, 'Натюрморт', 'Паудис, Христофер', 29, 1660, 'Германия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (83, 'Мадонна с Младенцем под яблоней', 'Паудис, Христофер', 29, 1530, 'Германия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (84, 'Моисей, иссекающий воду из скалы', 'Пуссен, Никола', 30, 1653, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (85, 'Битва израильтян с амаликитянами', 'Пуссен, Никола', 30, 1625, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (86, 'Танкред и Эрминия', 'Пуссен, Никола', 30, 1631, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (87, 'Автопортрет', 'Виже-Лебрен, Мари-Луиз-Элизабет', 31, 1800, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (88, 'Прачки в руинах', 'Робер, Гюбер', 31, 1760, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (89, 'У отшельника', 'Робер, Гюбер', 31, 1772, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (90, 'Портрет Джона Локка', 'Неллер, Годфри', 32, 1697, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (91, 'Кузница. Вид снаружи', 'Райт из Дерби, Джозеф', 32, 1773, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (92, 'Портрет Абрахама ван дер Дорта', 'Добсон, Уильям', 32, 1639, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (93, 'Портрет миссис Хэрриэт Грир', 'Ромни, Джордж', 32, 1788, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (94, 'Амур развязывает пояс Венеры', 'Рейнолдс, Джошуа', 32, 1788, 'Великобритания');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (95, 'Каминная решетка с двумя журавлями', NULL, 33, NULL, 'Китай');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (96, 'Кувшин для вина', NULL, 33, NULL, 'Китай');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (97, 'Сакья-Пандита', NULL, 34, NULL, 'Тибет');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (98, 'Астрологическая таблица с изображением животных двенадцатилетнего цикла', NULL, 34, NULL, 'Тибет');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (99, 'Водолей в виде орла', NULL, 35, 797, 'Ирак');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (100, 'Поднос', NULL, 35, NULL, 'Восточное средиземноморье');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (101, 'Кружка', 'Карл Альбрехт', 36, 1886, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (102, 'Портсигар со спичечницей и отверстием для фитиля', 'Михаил Перхин', 36, 1900, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (103, 'Доска закладная крейсера «Рюрик»', 'Андреас Невалайнен', 36, 1905, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (104, 'Часы настольные в форме грифона', 'Юлий Раппопорт', 37, 1904, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (105, 'Кувшин', 'Роберт Кохун', 37, 1875, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (106, 'Предметы из сервиза с монограммами великой княгини Ольги Николаевны', 'Карл-Иоганн Тегельстен, Генрих Август Лонг', 37, 1840, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (107, 'Парные канделябры на четыре свечи', 'Иоганн-Вильгельм Кейбель', 37, NULL, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (108, 'Пасхальное яйцо «Курочка»', 'Эрик Коллин', 38, 1885, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (109, 'Пасхальное яйцо «Ренессанс»', 'Михаил Перхин', 38, 1894, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (110, 'Яйцо «Воскресение Христово»', 'Михаил Перхин', 38, 1898, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (111, 'Пасхальное яйцо «Пятнадцатилетие царствования»', 'Генрик Вигстрём', 38, 1911, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (112, 'Пасхальное яйцо «Ландыши»', 'Михаил Перхин', 38, 1898, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (113, 'Пасхальное яйцо-часы «Петушок»', 'Михаил Перхин', 38, 1900, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (114, 'Настольные часы с портретами младших сыновей датского принца Вальдемара', 'Йохан Виктор Аарне', 39, 1890, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (115, 'Бонбоньерка в форме кресла', 'Генрик Вигстрём', 39, 1911, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (116, 'Флакон парфюмерный с крышкой в виде женской головки', 'Генрик Вигстрём', 39, 1908, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (117, 'Портсигар', 'Оскар Пиль', 40, 1897, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (118, 'Кулон и брошь', 'Альберт Хольмстрём', 40, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (119, 'Шкатулка в виде сундука с изображением гербов городов Рязанской губернии', 'Павел Акимович Овчинников', 41, 1893, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (120, 'Спичечница с эмалевой миниатюрой "Адмиралтейство"', 'Федор Рюкерт', 41, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (121, 'Шкатулка с эмалевой миниатюрой "Право господина" (по картине В. Поленова)', 'Федор Рюкерт', 41, 1908, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (122, 'Бюст императора Александра III', 'Генрик Вигстрём', 42, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (123, 'Настольные часы с глобусом', 'Генрик Вигстрём', 42, NULL, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (124, 'Икона «Покров Богоматери»', 'Дмитрий Андреев', 43, 1842, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (125, 'Икона «Святой Николай Чудотворец»', 'Михаил Дикарев', 43, 1894, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (126, 'Складень "Господь Вседержитель, Богоматерь с младенцем, Св. Николай Чудотворец"', 'Федор Рюкерт', 43, 1900, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (127, 'Ваза c изображением цветов', 'Федор Красовский', 44, 1859, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (128, 'Лето в Гурзуфе', 'Константин Коровин', 44, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (129, 'Вазочка для цветов', NULL, 45, 1908, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (130, 'Чаша', NULL, 45, 1880, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (131, 'Архангел Гавриил (Ангел Златые Власы)', NULL, 46, NULL, 'Древняя русь');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (132, 'Апостол Павел', 'Рублев Андрей', 46, 1408, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (133, 'Покров Богоматери', NULL, 46, NULL, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (134, 'Крещение', 'Рублев Андрей', 47, 1408, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (135, 'Апостол Петр', 'Рублев Андрей', 47, 1408, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (136, 'Портрет графини А. К. Воронцовой (урожденной Скавронской)', 'Антропов А. П.', 48, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (137, 'Портрет С. Э. Фермор', 'Вишняков И. Я.', 48, 1750, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (138, 'Портрет князя И. И. Лобанова-Ростовского', 'Аргунов И. П.', 48, 1750, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (139, 'Русская эскадра на Севастопольском рейде', 'Айвазовский И. К.', 49, 1846, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (140, 'Девятый вал', 'Айвазовский И. К.', 49, 1850, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (141, 'Волна', 'Айвазовский И. К.', 49, 1889, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (142, 'Аричча близ Рима', 'Лебедев М. И.', 50, 1836, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (143, 'Вид с Петровского острова в Петербурге', 'Щедрин С. Ф.', 50, 1816, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (144, 'Вид Неаполя. Набережная Санта Лючия', 'Щедрин С. Ф.', 50, 1829, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (145, 'Новый Рим. Замок Святого Ангела', 'Щедрин С. Ф.', 50, 1823, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (146, 'После дождя. Проселок', 'Васильев Ф. А.', 51, 1869, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (147, 'В церковной ограде. Валаам', 'Васильев Ф. А.', 51, 1867, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (148, 'Охотники на привале', 'Перов В. Г.', 52, 1877, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (149, 'Суд Пугачева', 'Перов В. Г.', 52, 1879, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (150, 'Джованнина, сидящая на подоконнике', 'Чистяков П. П.', 52, 1864, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (151, 'Дубы', 'Шишкин И. И.', 53, 1865, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (152, 'Корабельная роща', 'Шишкин И. И.', 53, 1898, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (153, 'Разлив Волги под Ярославлем', 'Саврасов А. К.', 54, 1871, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (154, 'Радуга', 'Саврасов А. К.', 54, 1875, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (155, 'Степь днём', 'Саврасов А. К.', 54, 1852, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (156, 'Бурлаки на Волге', 'Репин И. Е.', 55, 1873, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (157, 'Запорожцы', 'Репин И. Е.', 55, 1891, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (158, 'Шторм на Волге', 'Репин И. Е.', 55, 1891, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (159, 'Лунная ночь на Днепре', 'Куинджи А. И.', 56, 1880, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (160, 'Ночное', 'Куинджи А. И.', 56, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (161, 'Переход Суворова через Альпы в 1799 году', 'Суриков В. И.', 57, 1899, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (162, 'Покорение Сибири Ермаком', 'Суриков В. И.', 57, 1895, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (163, 'Взятие снежного городка', 'Суриков В. И.', 57, 1891, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (164, 'Витязь на распутье', 'Васнецов В. М.', 58, 1882, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (165, 'Бой скифов со славянами', 'Васнецов В. М.', 58, 1881, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (166, 'Богоматерь с младенцем', 'Васнецов В. М.', 58, 1887, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (167, 'Купание лошади', 'Серов В. А.', 59, 1905, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (168, 'Портрет княгини Ольги Орловой', 'Серов В. А', 59, 1911, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (169, 'Дети', 'Трубецкой П. (П. П.)', 59, 1910, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (170, 'Демон', 'Врубель М. А.', 60, 1894, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (171, 'Летящий демон', 'Врубель М. А.', 60, 1899, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (172, 'Венеция', 'Врубель М. А.', 60, 1893, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (173, 'Портрет Ивана Васильевича Клюна (Усовершенствованный портрет Клюна(Строитель))', 'Малевич К. С.', 61, 1913, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (174, 'Сумеречное', 'Кандинский В.В', 61, 1917, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (175, 'Красный квадрат (Живописный реализм крестьянки в двух измерениях)', 'Малевич К. С.', 61, 1915, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (176, 'Супрематизм (supremus № 56)', 'Малевич К. С.', 61, 1916, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (177, 'Человек + воздух + пространство', 'Попова Л.С.', 61, 1913, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (178, 'Черный квадрат', 'Малевич К. С.', 62, 1923, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (179, 'Спортсмены', 'Малевич К. С.', 62, 1932, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (180, 'Красная конница', 'Малевич К. С.', 62, 1932, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (181, 'Угловой контррельеф', 'Татлин В. Е.', 62, 1914, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (182, 'Dios con nosotros', 'Жилинский Д. Д.', 63, 1991, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (183, 'Стулья', 'Иммендорф Йорг', 63, 1980, 'Германия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (184, 'Большие головы', 'Пикассо Пабло', 63, 1969, 'Франция');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (185, 'Открытое окно', 'Матюшин М. В.', 64, 1920, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (186, 'Белая ночь. Кировские острова.', 'Гринберг В. А.', 64, 1940, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (187, 'В хлеву', 'Гуревич Д. Е.', 64, 1930, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (188, 'В поле', 'Костров И. Н.', 64, 1933, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (189, 'Двое. Сцена', 'Арефьев А. Д.', 65, 1953, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (190, 'Двое. Разговор в углу', 'Арефьев А. Д.', 65, 1955, 'Россия');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (191, 'На прудах', 'Шагин В. Н.', 65, 1980, 'СССР');
INSERT INTO public.exhibit (exhibit_id, exhibit_name, author, hall_id, year_of_creation, country_of_creation) VALUES (192, 'Синий кувшин', 'Шварц Ш. А.', 65, 1993, 'Россия');


-- insert into schedule
CREATE OR REPLACE PROCEDURE every_day 
   (
        excursion_id INT,
	   	open_time TIME,	   
	    close_time TIME,
	   inter INTERVAL,
	   first_day DATE,
	   last_day DATE,
	   days_off INT[]
   )
   language plpgsql  
   AS $$
   DECLARE schedule_id INT; excursion_time TIME; i_day DATE := first_day;
   BEGIN
		WHILE i_day < last_day LOOP
			excursion_time:= open_time;
			IF(days_off = '{}' OR extract(dow from i_day) <> ALL(days_off)) THEN
				WHILE excursion_time < close_time LOOP	
					SELECT MAX(schedule.schedule_id) into schedule_id from schedule;
					INSERT INTO public.schedule(schedule_id, excursion_id, starts_on)
						VALUES (COALESCE(schedule_id + 1, 1), Excursion_id, i_day + excursion_time);
					excursion_time := excursion_time + inter;
				END LOOP;
			END IF;	
			i_day := i_day + INTERVAL '1 day';
		END LOOP;
	END						
   $$;
   
   
CREATE OR REPLACE PROCEDURE every_week 
   (
        excursion_id INT,
        weekday INT,
	   	first_day DATE,
	   	last_day DATE,
	   	excursion_time TIME
   )
   language plpgsql  
   AS $$
   DECLARE v_schedule_id INT; i_day DATE := first_day + cast(abs(extract(dow FROM first_day) - 7) + weekday AS int);
   BEGIN
		WHILE i_day < last_day
		LOOP
			SELECT MAX(schedule.schedule_id) into v_schedule_id from schedule;
			INSERT INTO public.schedule(schedule_id, excursion_id, starts_on)
					VALUES (COALESCE(v_schedule_id + 1, 1), Excursion_id, i_day + excursion_time);
			i_day := i_day + INTERVAL '1 week';			
		END LOOP;
	END						
   $$;

 CALL every_day(001,'11:00:00', '18:00:00', INTERVAL '1 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_week(002, 2,'02.01.2023','31.03.2024', '13:40:00');
 CALL every_week(003, 3,'02.01.2023','31.03.2024', '12:00:00');
 CALL every_day(004,'10:00:00', '15:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{1}'); 
 CALL every_day(005,'11:00:00', '16:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{1}'); 
 CALL every_week(006, 3,'02.01.2023','31.03.2024', '15:00:00');
 CALL every_week(007, 3,'02.01.2023','31.03.2024', '17:00:00');
 CALL every_day(008,'12:00:00', '18:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{0, 1, 2}'); 
 CALL every_day(009,'12:00:00', '18:00:00', INTERVAL '4 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(010,'12:00:00', '18:00:00', INTERVAL '4 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(011,'12:00:00', '16:00:00', INTERVAL '1 hour', '02.01.2023','31.03.2024', '{}'); 
 CALL every_day(012,'11:00:00', '17:00:00', INTERVAL '1 hour', '02.01.2023','31.03.2024', '{}'); 
 CALL every_week(013, 3,'02.01.2023','31.03.2024', '11:00:00');
 CALL every_week(014, 3,'02.01.2023','31.03.2024', '12:00:00');
 CALL every_week(015, 3,'02.01.2023','31.03.2024', '14:30:00');
 CALL every_week(016, 3,'02.01.2023','31.03.2024', '15:00:00');
 CALL every_day(017,'12:00:00', '18:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(018,'12:00:00', '18:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(019,'12:00:00', '18:00:00', INTERVAL '4 hour', '02.01.2023','31.03.2024', '{2}'); 
 CALL every_day(020,'11:00:00', '18:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{2}'); 
 CALL every_week(021, 3,'02.01.2023','31.03.2024', '12:30:00');
 CALL every_day(022,'12:00:00', '18:00:00', INTERVAL '3 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(023,'12:00:00', '18:00:00', INTERVAL '3 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(024,'11:00:00', '18:00:00', INTERVAL '1 hour', '02.01.2023','31.03.2024', '{1, 2}'); 
 CALL every_day(025,'11:00:00', '18:00:00', INTERVAL '2 hour', '02.01.2023','31.03.2024', '{1, 2}'); 

DROP PROCEDURE every_week;
DROP PROCEDURE every_day;